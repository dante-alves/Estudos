<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercício 1</title>
    <style>
        body {
            text-align: center;
            font-size: 2em;
        }
    </style>
</head>
<body>
    <?php 
    
        $estados = ["Paraíba", "Pernambuco", "Ceará", "Rio de Janeiro", "São Paulo"];
        echo "$estados[3]";

    ?>
</body>
</html>